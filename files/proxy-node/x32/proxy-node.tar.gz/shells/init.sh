#!/bin/bash
getent group | grep clients &>/dev/null || groupadd clients

#/*****************
#* Timezone
#******************/
yum install ntp iptables wget -y

\cp -rf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

service ntpd stop

/usr/sbin/ntpdate    asia.pool.ntp.org

service ntpd start

chkconfig ntpd on


iptables -t nat -F
iptables -t nat -X
iptables -t nat -P PREROUTING ACCEPT
iptables -t nat -P POSTROUTING ACCEPT
iptables -t nat -P OUTPUT ACCEPT
iptables -t mangle -F
iptables -t mangle -X
iptables -t mangle -P PREROUTING ACCEPT
iptables -t mangle -P INPUT ACCEPT
iptables -t mangle -P FORWARD ACCEPT
iptables -t mangle -P OUTPUT ACCEPT
iptables -t mangle -P POSTROUTING ACCEPT
iptables -F
iptables -X
iptables -P FORWARD ACCEPT
iptables -P INPUT ACCEPT
iptables -P OUTPUT ACCEPT
iptables -t raw -F
iptables -t raw -X
iptables -t raw -P PREROUTING ACCEPT
iptables -t raw -P OUTPUT ACCEPT

iptables -P INPUT DROP

iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT

#ping
iptables -A INPUT -p icmp -j ACCEPT
iptables -A INPUT -i lo -j ACCEPT


#pptp
iptables -A INPUT -p tcp -m state --state NEW  --dport 1723 -j ACCEPT

#ssh
iptables -A INPUT -p tcp -m state --state NEW --dport 2222 -j ACCEPT
iptables -A INPUT -p tcp -m state --state NEW --dport 22 -j ACCEPT
#obf-ssh
iptables -A INPUT -p tcp -m state --state NEW --dport 2201 -j ACCEPT
#proxy-node
iptables -A INPUT -p tcp -m state --state NEW --dport 8080 -j ACCEPT
#www
iptables -A INPUT -p tcp -m state --state NEW --dport 80 -j ACCEPT

#shadowsocks
iptables -A INPUT -p tcp -m state --state NEW --dport 10000:60000  -j ACCEPT

#iptables -A INPUT -j REJECT --reject-with icmp-host-prohibited

service iptables save
service iptables restart

sed -i "s/Port 22/Port 2222/g" /etc/ssh/sshd_config
sed -i "s/#Port 22/Port 2222/g" /etc/ssh/sshd_config

sed -i "s/GSSAPIAuthentication yes/GSSAPIAuthentication no/g"  /etc/ssh/sshd_config
sed -i "s/#GSSAPIAuthentication no/GSSAPIAuthentication no/g"  /etc/ssh/sshd_config

sed -i "s/GSSAPICleanupCredentials/#GSSAPICleanupCredentials /g"  /etc/ssh/sshd_config

sed -i "s/UseDNS yes/UseDNS no/g" /etc/ssh/sshd_config
sed -i "s/#UseDNS no/UseDNS no/g" /etc/ssh/sshd_config

service sshd restart

#denyhosts
if [ ! -f epel-release-6-8.noarch.rpm ]
then
	arch=`uname -m`

	if [ $arch = "x86_64" ] 
	then
		wget -O epel-release-6-8.noarch.rpm http://dl.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm	
	else		
		wget -O epel-release-6-8.noarch.rpm http://dl.fedoraproject.org/pub/epel/6/i386/epel-release-6-8.noarch.rpm
	fi
fi

rpm -Uvh epel-release-6-8.noarch.rpm

sed -i "s/mirrorlist=https/mirrorlist=http/" /etc/yum.repos.d/epel.repo

service stop denyhosts
yum remove denyhosts -y
yum install denyhosts -y

sed -i "s/DENY_THRESHOLD_ROOT = 1/DENY_THRESHOLD_ROOT = 3/g" /etc/denyhosts.conf
sed -i "s/SMTP_HOST = localhost/SMTP_HOST = hwsmtp.exmail.qq.com/g" /etc/denyhosts.conf
sed -i "s/#SMTP_USERNAME=foo/SMTP_USERNAME=vps@reakoo.com/g" /etc/denyhosts.conf
sed -i "s/#SMTP_PASSWORD=bar/SMTP_PASSWORD=admin@reakoo414243/g" /etc/denyhosts.conf
sed -i "s/ADMIN_EMAIL = root/ADMIN_EMAIL = imlangzi@qq.com/g" /etc/denyhosts.conf


service denyhosts restart

#echo "export PATH=\$PATH:/usr/local/go/bin" >> /etc/profile
#echo "export GOROOT=/root/go" >> /etc/profile
#echo "export GOPATH=/root/go" >> /etc/profile

#echo "session    optional     pam_exec.so /usr/local/proxy-node/notify-session.sh" >> /etc/pam.d/sshd