#!/bin/bash

#[ "$PAM_TYPE" = "open_session" ] || exit 0
#{
#  echo "Type: $PAM_TYPE" >> /tmp/login.log
#  echo "User: $PAM_USER" >> /tmp/login.log
#  echo "Ruser: $PAM_RUSER" >> /tmp/login.log
#  echo "Rhost: $PAM_RHOST" >> /tmp/login.log
#  echo "Service: $PAM_SERVICE" >> /tmp/login.log
#  echo "TTY: $PAM_TTY" >> /tmp/login.log
#  echo "Date: `date`" >> /tmp/login.log
#  echo "Server: `uname -a`" >> /tmp/login.log
#} | mail -s "`hostname -s` $PAM_SERVICE login: $PAM_USER" root

#echo "x" >> /usr/local/proxy-node/notify-login.log
if [ "$PAM_TYPE" = "open_session" ] && [ "$PAM_USER" != "root" ] 
then
echo "$PAM_USER" >> /usr/local/proxy-node/notify-login.log
	/usr/local/proxy-node/notify-login -d=/usr/local/proxy-node -u=$PAM_USER >> /usr/local/proxy-node/notify-login.log
fi


if [ "$PAM_TYPE" = "close_session" ] && [ "$PAM_USER" != "root" ]
then
	/usr/local/proxy-node/notify-logout -d=/usr/local/proxy-node -u=$PAM_USER >> /usr/local/proxy-node/notify-logout.log
fi
