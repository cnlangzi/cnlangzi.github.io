#!/bin/bash
if [ -n "$1" ] && [ "$1" != "root" ]; then
	userdel -r $1
	
	sed -i "/$1 /d" /etc/ppp/chap-secrets
	
	killall -HUP shadowsocks-server
#	return $? 
fi