#!/bin/bash

#getent group clients | awk -F : '{print $4}'
gid="$(getent group clients | awk -F : '{print $3}')"

cat /etc/passwd | grep ${gid} | awk -F ':' '{print $1}'
