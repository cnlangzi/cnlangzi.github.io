#!/bin/bash
USER=$1
PASSWORD=$2

if [ -n "$USER" ] && [ "$USER" != "root" ]; then    
	getent group | grep clients &>/dev/null || groupadd clients
	
	gid="$(getent group clients | awk -F : '{print $3}')"
	
	id $USER &>/dev/null || useradd -g ${gid} $USER -s /sbin/nologin
	
	usermod -g ${gid} $USER
	 
	#id $USER | grep clients &>/dev/null || (gpasswd -d $USER $USER && gpasswd -a $USER clients)	
	
	echo "${USER}:${PASSWORD}" | chpasswd
	
	sed -i "/${USER} /d" /etc/ppp/chap-secrets
	
	echo "${USER} * ${PASSWORD} *" >> /etc/ppp/chap-secrets
	
	killall -HUP shadowsocks-server
#	return $? 
fi
