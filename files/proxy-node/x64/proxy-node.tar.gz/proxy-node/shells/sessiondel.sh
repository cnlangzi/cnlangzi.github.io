#!/bin/bash

ps aux | grep "sshd: $1" | grep -v grep | grep -v priv | awk '{print $2}' | sort  | head -n 1 | xargs kill -9

/usr/local/proxy-node/notify-logout -d=/usr/local/proxy-node -u=$1 >> /usr/local/proxy-node/notify-logout.log   
