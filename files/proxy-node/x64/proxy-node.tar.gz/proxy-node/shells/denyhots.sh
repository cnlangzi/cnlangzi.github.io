#!/bin/bash


if [ ! -f epel-release-6-8.noarch.rpm ]
then
	arch=`uname -m`

	if [ $arch = "x86_64" ] 
	then
		wget http://dl.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm	
	else
		rm -rf epel-release-6-8.noarch.rpm
		wget http://dl.fedoraproject.org/pub/epel/6/i386/epel-release-6-8.noarch.rpm
	fi
fi

rpm -Uvh epel-release-6-8.noarch.rpm

service stop denyhosts
yum remove denyhosts -y
yum install denyhosts -y

sed -i "s/DENY_THRESHOLD_ROOT = 1/DENY_THRESHOLD_ROOT = 3/g" /etc/denyhosts.conf
sed -i "s/SMTP_HOST = localhost/SMTP_HOST = hwsmtp.exmail.qq.com/g" /etc/denyhosts.conf
sed -i "s/#SMTP_USERNAME=foo/SMTP_USERNAME=vps@reakoo.com/g" /etc/denyhosts.conf
sed -i "s/#SMTP_PASSWORD=bar/SMTP_PASSWORD=admin@reakoo414243/g" /etc/denyhosts.conf
sed -i "s/ADMIN_EMAIL = root/ADMIN_EMAIL = imlangzi@qq.com/g" /etc/denyhosts.conf


service denyhosts restart