mv ./go-shadowsocks2 /usr/local/bin/go-shadowsocks2

mv ./shadowsocks-server.service /etc/systemd/system/

systemctl enable shadowsocks-server
systemctl start shadowsocks-server
systemctl status shadowsocks-server